

export default function RedBox() {
  return (
    <div>
      <p>Hello,<span style={{color:'red'}}>RedBox</span></p>
    </div>
  )
}

export function BlueBox() {
  return (
    <div>
      <p>Hello,<span style={{color:'blue'}}>BlueBo6x</span></p>
    </div>
  )
}

export function GreenBox() {
  return (
    <div>
      <p>Hello,<span style={{color:'green'}}>GreenBox</span></p>
    </div>
  )
}
